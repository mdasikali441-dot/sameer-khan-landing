# Sameer Khan [2014] Telegram Landing Page

## GitHub Pages-এ প্রকাশ করার নিয়ম
1. GitHub.com-এ সাইন ইন করে **New repository** চাপুন।
2. Repository name দিন `sameer-khan-landing` এবং **Public** নির্বাচন করুন।
3. **Create repository** চাপুন।
4. **Add file → Upload files** থেকে `index.html` এবং `reference-poster.png`—দুটি ফাইল আপলোড করুন।
5. **Commit changes** চাপুন।
6. Repository-র **Settings → Pages** খুলুন।
7. **Build and deployment**-এ `Deploy from a branch` নির্বাচন করুন; Branch `main`, folder `/(root)` নির্বাচন করে **Save** দিন।
8. কিছুক্ষণ পর Pages পাতায় দেখানো `https://YOUR-USERNAME.github.io/sameer-khan-landing/` লিংকে সাইট চালু হবে।

Telegram Join button is already configured to open: https://t.me/+YdRkhD86u2w1NzRl
